export const GET_ADMIN_DATA = "GET_ADMIN_DATA";

export const SEARCH_DATA = "SEARCH_DATA";

export const EDIT_ADMIN_DATA = "EDIT_ADMIN_DATA";

export const DELETE_SINGLE_DATA = "DELETE_SINGLE_DATA";

export const DELETE_MULTIPLE_DATA = "DELETE_MULTIPLE_DATA";

export const SET_PAGE = "SET_PAGE";
